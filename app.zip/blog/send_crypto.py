from bit import PrivateKeyTestnet as Key


def send(mk, wallet, money):
	try:
		k = Key(mk)
		print(k.get_balance("usd"))
		outputs = [(wallet, money, "btc")]
		k.send(outputs)
	except Exception as e:
		print(e)

def get_tr(mk):
	k = Key(mk)
	transactions = k.get_transactions()
	print(transactions)
