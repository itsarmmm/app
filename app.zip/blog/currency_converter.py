import requests
import math

class CurrencyConverter:
    # empty dict to store the conversion rates
    rates = {}
    def __init__(self, url):
        data = requests.get(url).json()

        # Extracting only the rates from the json data
        self.rates = data["conversion_rates"]

    # function to do a simple cross multiplication between
    # the amount and the conversion rates
    def convert(self):

        return self.rates["AMD"]

        # # if type == "buy":
        #     amount = amount + (amount * percent) / 100




    def add_commission(self, amount):

        amount = amount + (amount * 6) / 100

        amount = round(amount, -2)

        return int(amount)

    def clean_convert(self, amount):

        amount = self.rates["AMD"]



        return amount





class CryptoConverter:
    def __init__(self, url):
        data = requests.get(url).json()

        self.rates = data[0]

    def crypto_convert(self, amount):

        amount = amount / float(self.rates["price"])

        return round(amount, 8)
