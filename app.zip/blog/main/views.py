from django.shortcuts import render, redirect
from django.http import HttpResponse
from main.models import Users, Orders
from django.db.models import Sum


# Create your views here.


def index(request):
    users = Users.objects.all()
    data = {
        'users': users
    }
    return render(request, 'main/index.html', data)



def orders(request):

    orders = Orders.objects.all()
    data = {
        'orders': orders
    }

    if 'deleteOrder' in request.GET:
        del_id = request.GET['deleteOrder']
        Orders.objects.filter(id=del_id).delete()
        return redirect("orders")

    return render(request, 'main/orders.html', data)

def pending_orders(request):
    pending_orders = Orders.objects.all().order_by('-order_date')
    data = {
        'pending_orders': pending_orders
    }

    if 'cancelOrder' in request.GET:
        cancel_id = request.GET['cancelOrder']
        Orders.objects.filter(id=cancel_id).update(status = "Canceled")
        return redirect("pending_orders")

    if 'deleteOrder' in request.GET:
        del_id = request.GET['deleteOrder']
        Orders.objects.filter(id=del_id).delete()
        return redirect("pending_orders")

    if 'acceptOrder' in request.GET:
        accept_id = request.GET['acceptOrder']
        Orders.objects.filter(id=accept_id).update(status = "Completed")
        return redirect("pending_orders")


    return render(request, 'main/pending_orders.html', data)


def partners(request):

    total_balance = Users.objects.aggregate(Sum('partner_balance'))

    partners = Users.objects.all().filter(is_partner=1)
    data = {
        'partners': partners,
        'total_balance': total_balance
    }

    if 'resetBalance' in request.GET:
        reset_id = request.GET['resetBalance']
        Users.objects.filter(user_id=reset_id).update(partner_balance = 0)
        return redirect("partners")

    if 'resetAll' in request.GET:
        for partner in partners:
            partners.filter(user_id=partner.user_id).update(partner_balance = 0)
        return redirect("partners")

    return render(request, 'main/partners.html', data)
