from django.db import models
from datetime import datetime

# Create your models here.


class Users(models.Model):
    user_id = models.IntegerField(primary_key=False)
    # first_name = models.CharField(max_length=40, null=True, blank=True)
    # last_name = models.CharField(max_length=40)
    # username = models.CharField(max_length=40)
    # phone = models.CharField(max_length=40)
    is_partner = models.IntegerField(default=0)
    partner_balance = models.IntegerField(default=0)
    order_type = models.CharField(max_length=40)
    price = models.IntegerField()
    pay_price = models.IntegerField(default=0)
    currency = models.IntegerField(primary_key=False)
    crypto_currency = models.CharField(max_length=40)
    pay_method = models.CharField(max_length=40)
    referrer = models.CharField(max_length=40, default = " ")
    partner_account_number = models.CharField(max_length=40, default = " ")


class Orders(models.Model):
    user_id = models.IntegerField(primary_key=False)
    order_type = models.CharField(max_length=40)
    price = models.IntegerField()
    crypto_currency = models.CharField(max_length=40)
    pay_method = models.CharField(max_length=40)
    status = models.CharField(max_length=40, default = "pending")
    receipt = models.CharField(max_length=40, default = "0")
    order_date = models.DateTimeField()

class Rates(models.Model):
    usd_to_amd = models.CharField(max_length=40)
    date = models.DateField(null=True, blank=True)
