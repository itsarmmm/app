import requests
from bs4 import BeautifulSoup as bs
import time

headers = {
    'authority': 'banking.idram.am',
    'sec-ch-ua': '" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
    'lang': 'am',
    '_encmethod_': 'NONE',
    'sec-ch-ua-mobile': '?0',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36',
    'content-type': 'application/json',
    'accept': '*/*',
    'origin': 'https://banking.idram.am',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://banking.idram.am/Account/login',
    'accept-language': 'en-US,en;q=0.9',
    'cookie': '_ga=GA1.2.1603291354.1628625293; _gid=GA1.2.1643070064.1629140341; _gat=1; webSessionId=pmtimvm35tkdlv0scfnrkmwz; __RequestVerificationToken=yZaNexj9LAADvtaRmhx0WIMIH6zNTm9oV45m-oABq9ORu6JiY77hI1tcXC_1fPck9aT8N7GDLNlKHvaukxOj7O4lngKBhzZJxrA__lPjiPw1; _gat_gtag_UA_138868487_1=1',
}

data = '{"u":"+37441551355"}'

response = requests.post('https://banking.idram.am/api/SignUp/PreSignUp', headers=headers, data=data)

time.sleep(3)

import requests

headers = {
    'authority': 'banking.idram.am',
    'sec-ch-ua': '" Not;A Brand";v="99", "Google Chrome";v="91", "Chromium";v="91"',
    'lang': 'am',
    '_encmethod_': 'NONE',
    'sec-ch-ua-mobile': '?0',
    'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36',
    'content-type': 'application/json',
    'accept': '*/*',
    'origin': 'https://banking.idram.am',
    'sec-fetch-site': 'same-origin',
    'sec-fetch-mode': 'cors',
    'sec-fetch-dest': 'empty',
    'referer': 'https://banking.idram.am/Account/login',
    'accept-language': 'en-US,en;q=0.9',
    'cookie': '_ga=GA1.2.1603291354.1628625293; _gid=GA1.2.1643070064.1629140341; webSessionId=pmtimvm35tkdlv0scfnrkmwz; __RequestVerificationToken=yZaNexj9LAADvtaRmhx0WIMIH6zNTm9oV45m-oABq9ORu6JiY77hI1tcXC_1fPck9aT8N7GDLNlKHvaukxOj7O4lngKBhzZJxrA__lPjiPw1',
}

data = '{"u":"+37441551355","p":"Arm.551355"}'

login_res = requests.post('https://banking.idram.am/api/Signin/Login', headers=headers, data=data)

finish = requests.get("https://banking.idram.am/pages/transactions-state?state=confirmed")

soup = bs(finish.content, "html.parser")

with open("index.txt", "w+") as f:
    f.write(str(soup))

print(soup)
