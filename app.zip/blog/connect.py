import sqlite3

class SQLighter:
    def __init__(self, database):
        # Connecting to database
        self.connection = sqlite3.connect(database)
        self.cursor = self.connection.cursor()

    def get_subscriptions(self, status = True):
        with self.connection:
            res = self.cursor.execute("SELECT * FROM `main_users` WHERE `status` = ?", (status,)).fetchall()
            users = []
            for i in range(len(res)):
                users.append(res[i][1])
            return users


    def user_exists(self, user_id):
        with self.connection:
            result = self.cursor.execute('SELECT * FROM `main_users` WHERE `user_id` = ?', (user_id,)).fetchall()
            return bool(len(result))


    def subscriber_exists(self, user_id):
        with self.connection:
            result = self.cursor.execute('SELECT * FROM `main_orders` WHERE `user_id` = ?', (user_id,)).fetchall()
            return bool(len(result))

    def add_subscriber(self, user_id, is_partner = False):
        with self.connection:
            return self.cursor.execute("INSERT INTO `main_users` (`user_id`, `is_partner`) VALUES(?,?)", (user_id, is_partner))

    def add_order(self, user_id):
        with self.connection:
            return self.cursor.execute("INSERT INTO `orders` (`user_id`) VALUES(?)", (user_id,))

    def set_order_type(self, user_id, order_type):
        with self.connection:
            return self.cursor.execute("UPDATE `main_users` SET `order_type` = ? WHERE `user_id` = ?", (order_type, user_id))

    def get_order_type(self, user_id):
        with self.connection:
            return self.cursor.execute("SELECT `order_type` FROM `main_users` WHERE `user_id` = ?", (user_id,)).fetchone()[0]

    def set_method(self, user_id, pay_method):
        with self.connection:
            return self.cursor.execute("UPDATE `main_users` SET `pay_method` = ? WHERE `user_id` = ?", (pay_method, user_id))

    def get_method(self, user_id):
        with self.connection:
            return self.cursor.execute("SELECT `pay_method` FROM `main_users` WHERE `user_id` = ?", (user_id,)).fetchone()[0]

    def set_currency(self, user_id, currency):
        with self.connection:
            return self.cursor.execute("UPDATE `main_users` SET `currency` = ? WHERE `user_id` = ?", (currency, user_id))

    def get_currency(self, user_id):
        with self.connection:
            return self.cursor.execute("SELECT `currency` FROM `main_users` WHERE `user_id` = ?", (user_id,)).fetchone()[0]

    def set_price(self, user_id, price):
        with self.connection:
            return self.cursor.execute("UPDATE `main_users` SET `price` = ? WHERE `user_id` = ?", (price, user_id))

    def get_price(self, user_id):
        with self.connection:
            return self.cursor.execute("SELECT `price` FROM `main_users` WHERE `user_id` = ?", (user_id,)).fetchone()[0]

    def get_pay_price(self, user_id):
        with self.connection:
            return self.cursor.execute("SELECT `pay_price` FROM `main_users` WHERE `user_id` = ?", (user_id,)).fetchone()[0]


    def set_pay_price(self,user_id, pay_price):
        with self.connection:
            return self.cursor.execute("UPDATE `main_users` SET `pay_price` = ? WHERE `user_id` = ?", (pay_price, user_id))


    def set_crypto_currency(self, user_id, crypto_currency):
        with self.connection:
            return self.cursor.execute("UPDATE `main_users` SET `crypto_currency` = ? WHERE `user_id` = ?", (crypto_currency, user_id))

    def get_crypto_currency(self, user_id):
        with self.connection:
            return self.cursor.execute("SELECT `crypto_currency` FROM `main_users` WHERE `user_id` = ?", (user_id,)).fetchone()[0]


    def get_last_orderId(self):
        with self.connection:
            return self.cursor.execute("SELECT `id` FROM `main_orders` ORDER BY `id` DESC LIMIT 1").fetchone()[0]


    def get_current_order(self, user_id):
        with self.connection:
            max_user_id = self.cursor.execute('SELECT `user_id` FROM `main_orders` WHERE `user_id` = ? ORDER BY `order_date` DESC LIMIT 1', (user_id,)).fetchone()[0]
            max_id = self.cursor.execute('SELECT `id` FROM `main_orders` ORDER BY `order_date` DESC LIMIT 1').fetchone()[0]
            return self.cursor.execute("SELECT `id` FROM `main_orders` WHERE `user_id` = ? AND `id` = ?", (max_user_id, max_id)).fetchone()[0]


    def set_receipt(self, user_id, receipt):
        with self.connection:
            max_user_id = self.cursor.execute('SELECT `user_id` FROM `main_orders` WHERE `user_id` = ? ORDER BY `order_date` DESC LIMIT 1', (user_id,)).fetchone()[0]
            max_id = self.cursor.execute('SELECT `id` FROM `main_orders` ORDER BY `order_date` DESC LIMIT 1').fetchone()[0]
            return self.cursor.execute("UPDATE `main_orders` SET `receipt` = ? WHERE `user_id` = ? AND `id` = ?", (receipt, max_user_id, max_id))

    def set_status(self, user_id, status):
        with self.connection:
            max_user_id = self.cursor.execute('SELECT `user_id` FROM `main_orders` WHERE `user_id` = ? ORDER BY `order_date` DESC LIMIT 1', (user_id,)).fetchone()[0]
            max_id = self.cursor.execute('SELECT `id` FROM `main_orders` ORDER BY `order_date` DESC LIMIT 1').fetchone()[0]
            return self.cursor.execute("UPDATE `main_orders` SET `status` = ? WHERE `user_id` = ? AND `id` = ?", (status, max_user_id, max_id))

    def set_referrer(self, user_id, referrer):
        with self.connection:
            return self.cursor.execute("UPDATE `main_users` SET `referrer` = ? WHERE `user_id` = ?", (referrer, user_id))


    def get_referrer(self, user_id):
        with self.connection:
            return self.cursor.execute('SELECT `referrer` FROM `main_users` WHERE `user_id` = ?', (user_id,)).fetchone()[0]

    def add_partner_balance(self, user_id, amount):
        with self.connection:
            referrer_id = self.cursor.execute('SELECT `referrer` FROM `main_users` WHERE `user_id` = ?', (user_id,)).fetchone()[0]
            previous_balance = self.cursor.execute('SELECT `partner_balance` FROM `main_users` WHERE `user_id` = ?', (referrer_id,)).fetchone()[0]
            new_balance = int(previous_balance) + int(amount)
            return self.cursor.execute("UPDATE `main_users` SET `partner_balance` = ? WHERE `user_id` = ?", (new_balance, referrer_id))


    def update_partner_status(self, user_id):
        with self.connection:
            return self.cursor.execute("UPDATE `main_users` SET `is_partner` = ? WHERE `user_id` = ?", (1, user_id))


    def get_partner_status(self, user_id):
        with self.connection:
            return self.cursor.execute('SELECT `is_partner` FROM `main_users` WHERE `user_id` = ?', (user_id,)).fetchone()[0]


    def get_partner_balance(self, user_id):
        return self.cursor.execute('SELECT `partner_balance` FROM `main_users` WHERE `user_id` = ?', (user_id,)).fetchone()[0]


    def get_status(self, user_id):
        with self.connection:
            max_user_id = self.cursor.execute('SELECT `user_id` FROM `main_orders` WHERE `user_id` = ? ORDER BY `order_date` DESC LIMIT 1', (user_id,)).fetchone()[0]
            max_id = self.cursor.execute('SELECT `id` FROM `main_orders` ORDER BY `order_date` DESC LIMIT 1').fetchone()[0]
            return self.cursor.execute("SELECT `status` FROM `main_orders` WHERE `user_id` = ? AND `id` = ?", (max_user_id, max_id)).fetchone()[0]


    def delete_order(self, user_id):
        with self.connection:
            max_user_id = self.cursor.execute('SELECT `user_id` FROM `main_orders` WHERE `user_id` = ? ORDER BY `order_date` DESC LIMIT 1', (user_id,)).fetchone()[0]
            max_id = self.cursor.execute('SELECT `id` FROM `main_orders` ORDER BY `order_date` DESC LIMIT 1').fetchone()[0]
            return self.cursor.execute("DELETE FROM `main_orders` WHERE `user_id` = ? AND `id` = ?", (max_user_id, max_id))


    def get_last_client(self):
        with self.connection:
            return self.cursor.execute("SELECT `user_id` FROM `main_orders` WHERE `status` = 'Pending' ORDER BY `order_date` DESC LIMIT 1").fetchone()[0]



    def get_all(self, user_id):
        with self.connection:
            return self.cursor.execute("SELECT * FROM `main_users` WHERE `user_id` = ?", (user_id,)).fetchall()


    def create_order(self, user_id, order_type, price, crypto_currency, pay_method, order_date):
        with self.connection:
            return self.cursor.execute("INSERT INTO `main_orders` (`user_id`, `order_type`, `price`, `crypto_currency`, `pay_method`, `order_date`) VALUES(?,?,?,?,?,?)", (user_id, order_type, price, crypto_currency, pay_method, order_date))


    def add_daily_rate(self, rate, date):
        with self.connection:
            return self.cursor.execute("INSERT INTO `main_rates` (`usd_to_amd`, `date`) VALUES(?,?)", (rate, date,))

    def get_rate(self):
        with self.connection:
            return self.cursor.execute("SELECT `usd_to_amd` FROM `main_rates` ORDER BY `id` DESC LIMIT 1").fetchone()[0]

    def close(self):
        self.connection.close()
